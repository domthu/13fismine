class Template < ActiveRecord::Base
end
