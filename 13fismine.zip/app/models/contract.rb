class Contract < ActiveRecord::Base
end
