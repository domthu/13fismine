class ContractUser < ActiveRecord::Base
end
