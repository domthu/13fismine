// translated by Dzintars Bergs (dzintars.bergs@gmail.com)
jsToolBar.strings = {};
jsToolBar.strings['Strong'] = 'Treknraksts';
jsToolBar.strings['Italic'] = 'Slīpraksts';
jsToolBar.strings['Underline'] = 'Pasvītrojums';
jsToolBar.strings['Deleted'] = 'Dzēsts';
jsToolBar.strings['Code'] = 'Iekļauts kods';
jsToolBar.strings['Heading 1'] = 'Virsraksts 1';
jsToolBar.strings['Heading 2'] = 'Virsraksts 2';
jsToolBar.strings['Heading 3'] = 'Virsraksts 3';
jsToolBar.strings['Unordered list'] = 'Nesakārtots saraksts';
jsToolBar.strings['Ordered list'] = 'Sakārtots saraksts';
jsToolBar.strings['Quote'] = 'Citēt';
jsToolBar.strings['Unquote'] = 'Noņemt citātu';
jsToolBar.strings['Preformatted text'] = 'Iepriekš formatēts teksts';
jsToolBar.strings['Wiki link'] = 'Saite uz Wiki lapu';
jsToolBar.strings['Image'] = 'Attēls';
