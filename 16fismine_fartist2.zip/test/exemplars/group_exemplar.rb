class Group < Principal
  generator_for :lastname, :start => 'Group'

end
