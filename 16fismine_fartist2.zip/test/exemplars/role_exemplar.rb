class Role < ActiveRecord::Base
  generator_for :name, :start => 'Role0'

end
