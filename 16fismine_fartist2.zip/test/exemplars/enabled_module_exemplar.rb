class EnabledModule < ActiveRecord::Base
  generator_for :name, :start => 'module_001'

end
