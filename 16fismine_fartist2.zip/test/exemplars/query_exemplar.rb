class Query < ActiveRecord::Base
  generator_for :name, :start => 'Query 0'

end
