class TimeEntryActivity < Enumeration
  generator_for :name, :start => 'TimeEntryActivity0'
  generator_for :type => 'TimeEntryActivity'

end
