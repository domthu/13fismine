# encoding: utf-8
#
module IssueMovesHelper
end
